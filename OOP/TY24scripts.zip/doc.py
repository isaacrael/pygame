class Test(object):
	''' This is just a test object.
		It doesn't do much, really.
	'''

	def __init__(self):
		''' This sets up the Test object. Doesn't
			take any parameters.
		'''
		self.num = 10
