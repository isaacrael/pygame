breakfast_special = "Texas Omelet"
breakfast_notes = "Contains brisket, horseradish cheddar"
lunch_special = "Greek patty melt"
lunch_notes = "Like the regular one, but with tzatziki sauce"
dinner_special = "Buffalo steak"
dinner_notes = "Top loin with hot sauce and blue cheese. NOT BUFFALO MEAT."

print "Today's specials"
print "*"*20
print "Breakfast:"
print breakfast_special
print breakfast_notes
print
print "Lunch:"
print lunch_special
print lunch_notes
print
print "Dinner:"
print dinner_notes
print dinner_special