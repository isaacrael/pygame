total = 13 + 14.02 + 22.35
party = 3


print "Receipt for your meal"
print total
if party >= 8:
	total = total + total * .2
	print "We've added on the tip automatically, since your party was eight or larger."
print "Thank you for dining with us today!"